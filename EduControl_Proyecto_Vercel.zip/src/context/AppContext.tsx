/**
 * EduControl Application Context & State Provider
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserAccount,
  UserRole,
  Student,
  Teacher,
  Classroom,
  Course,
  Enrollment,
  ScheduleSlot,
  AttendanceRecord,
  GradeRecord,
  PaymentRecord,
  Announcement,
  CustomRole,
  SchoolConfig,
  AuditLog,
  PushNotification
} from '../types';
import { StorageService, DatabaseState } from '../services/storage';
import { NotificationService } from '../services/notifications';

export type AppModule = 
  | 'dashboard'
  | 'usuarios'
  | 'alumnos'
  | 'docentes'
  | 'aulas'
  | 'cursos'
  | 'matriculas'
  | 'horarios'
  | 'asistencias'
  | 'calificaciones'
  | 'pagos'
  | 'comunicados'
  | 'reportes'
  | 'configuracion';

interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
}

interface AppContextType {
  // Current user & role simulation
  currentUser: UserAccount;
  currentRole: UserRole;
  setCurrentUser: (user: UserAccount) => void;
  switchRole: (role: UserRole) => void;
  canAccessModule: (module: string) => boolean;

  // Active navigation
  activeModule: AppModule;
  setActiveModule: (mod: AppModule) => void;

  // Database State
  config: SchoolConfig;
  updateConfig: (newConfig: Partial<SchoolConfig>) => void;
  users: UserAccount[];
  roles: CustomRole[];
  students: Student[];
  teachers: Teacher[];
  classrooms: Classroom[];
  courses: Course[];
  enrollments: Enrollment[];
  schedules: ScheduleSlot[];
  attendances: AttendanceRecord[];
  grades: GradeRecord[];
  payments: PaymentRecord[];
  announcements: Announcement[];
  notifications: PushNotification[];
  auditLogs: AuditLog[];

  // Entity mutations
  saveStudent: (student: Student) => void;
  deleteStudent: (studentId: string) => void;
  saveTeacher: (teacher: Teacher) => void;
  deleteTeacher: (teacherId: string) => void;
  saveClassroom: (classroom: Classroom) => void;
  deleteClassroom: (classroomId: string) => void;
  saveCourse: (course: Course) => void;
  deleteCourse: (courseId: string) => void;
  saveEnrollment: (enrollment: Enrollment) => void;
  saveScheduleSlot: (slot: ScheduleSlot) => void;
  deleteScheduleSlot: (slotId: string) => void;
  recordAttendanceBatch: (records: AttendanceRecord[]) => void;
  saveGrade: (grade: GradeRecord) => void;
  recordPayment: (payment: PaymentRecord) => void;
  createAnnouncement: (announcement: Announcement, sendPush?: boolean) => void;
  saveCustomRole: (role: CustomRole) => void;
  saveUserAccount: (user: UserAccount) => void;

  // Notifications & Alerts
  markNotificationRead: (id: string) => void;
  clearAllNotifications: () => void;
  triggerPushAlert: (title: string, body: string, isCritical?: boolean) => void;
  runPeriodicAutomatedReport: () => void;

  // Toast System
  toasts: ToastMessage[];
  addToast: (type: 'success' | 'error' | 'info' | 'warning', title: string, message: string) => void;
  removeToast: (id: string) => void;

  // Security E2EE
  encryptionUnlocked: boolean;
  setEncryptionUnlocked: (unlocked: boolean) => void;

  // Backup & Reset
  exportDatabaseJSON: () => void;
  exportDatabaseSQL: () => void;
  importDatabaseJSON: (data: DatabaseState) => void;
  resetDatabase: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [dbState, setDbState] = useState<DatabaseState>(() => StorageService.loadState());
  const [activeModule, setActiveModule] = useState<AppModule>('dashboard');
  
  // Default to Superadmin or Director for full demo exploration
  const [currentUser, setCurrentUser] = useState<UserAccount>(() => {
    return dbState.users.find(u => u.role === 'director') || dbState.users[0];
  });
  const [currentRole, setCurrentRole] = useState<UserRole>(currentUser.role);

  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [encryptionUnlocked, setEncryptionUnlocked] = useState<boolean>(true);

  // Sync state to storage whenever it changes
  useEffect(() => {
    StorageService.saveState(dbState);
  }, [dbState]);

  const addToast = (type: 'success' | 'error' | 'info' | 'warning', title: string, message: string) => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts(prev => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const logAudit = (action: string, module: string, details: string) => {
    const newLog: AuditLog = {
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentRole,
      action,
      module,
      details,
      ipAddress: '192.168.1.15',
    };
    setDbState(prev => ({
      ...prev,
      auditLogs: [newLog, ...prev.auditLogs.slice(0, 99)],
    }));
  };

  // Switch role simulator
  const switchRole = (role: UserRole) => {
    setCurrentRole(role);
    const userForRole = dbState.users.find(u => u.role === role) || {
      id: `usr-${role}`,
      name: `Usuario de Prueba (${role})`,
      email: `${role}@colegio.edu`,
      role,
      status: 'activo',
    };
    setCurrentUser(userForRole);
    addToast('info', 'Rol Activo Cambiado', `Ahora estás visualizando el sistema como: ${role.toUpperCase()}`);
    logAudit('CAMBIO_ROL_SIMULADO', 'Seguridad', `Cambio de contexto a rol: ${role}`);
  };

  // Permission verification
  const canAccessModule = (module: string): boolean => {
    if (currentRole === 'superadmin') return true;
    const roleDef = dbState.roles.find(r => r.id === `role-${currentRole}`);
    if (!roleDef) return true;
    const perm = roleDef.permissions[module];
    return perm ? (perm.read || perm.create || perm.update) : true;
  };

  // Trigger push alert
  const triggerPushAlert = (title: string, body: string, isCritical: boolean = false) => {
    NotificationService.sendNativePush(title, body, isCritical);
    const newNotif: PushNotification = {
      id: `notif-${Date.now()}`,
      title,
      body,
      timestamp: new Date().toISOString(),
      type: isCritical ? 'critica' : 'info',
      read: false,
    };
    setDbState(prev => ({
      ...prev,
      notifications: [newNotif, ...prev.notifications],
    }));
    addToast(isCritical ? 'error' : 'info', title, body);
  };

  // Automated Periodic Report Trigger (simulates scheduled cron in browser)
  const runPeriodicAutomatedReport = () => {
    const today = new Date().toISOString().slice(0, 10);
    const totalStudents = dbState.students.length;
    const todayAtt = dbState.attendances.filter(a => a.date === today);
    const present = todayAtt.filter(a => a.status === 'presente').length;
    const attendancePct = todayAtt.length > 0 ? ((present / todayAtt.length) * 100).toFixed(0) : '94';
    
    const overdueCount = dbState.payments.filter(p => p.status === 'vencido').length;

    const reportTitle = '📊 Informe Operativo Automatizado';
    const reportBody = `Corte del día: Asistencia ${attendancePct}% (${present}/${todayAtt.length || totalStudents}). ${overdueCount} cuotas vencidas pendientes.`;

    triggerPushAlert(reportTitle, reportBody, false);
    logAudit('INFORME_AUTOMATICO_GENERADO', 'Reportes', 'Disparo de reporte programado de operatividad académica');
  };

  // Mutations
  const updateConfig = (newConfig: Partial<SchoolConfig>) => {
    setDbState(prev => ({
      ...prev,
      config: { ...prev.config, ...newConfig },
    }));
    addToast('success', 'Configuración Guardada', 'Los parámetros institucionales fueron actualizados con éxito.');
    logAudit('CONFIGURACION_ACTUALIZADA', 'Configuración', 'Cambios guardados en parámetros de la institución');
  };

  const saveStudent = (student: Student) => {
    setDbState(prev => {
      const exists = prev.students.some(s => s.id === student.id);
      return {
        ...prev,
        students: exists
          ? prev.students.map(s => (s.id === student.id ? student : s))
          : [student, ...prev.students],
      };
    });
    addToast('success', 'Expediente de Alumno', `${student.lastName}, ${student.firstName} guardado correctamente.`);
    logAudit('GUARDAR_ALUMNO', 'Alumnos', `Registro/actualización del estudiante ${student.code}`);
  };

  const deleteStudent = (studentId: string) => {
    setDbState(prev => ({
      ...prev,
      students: prev.students.filter(s => s.id !== studentId),
    }));
    addToast('warning', 'Alumno Eliminado', 'El estudiante fue retirado del padrón.');
    logAudit('ELIMINAR_ALUMNO', 'Alumnos', `Eliminado ID: ${studentId}`);
  };

  const saveTeacher = (teacher: Teacher) => {
    setDbState(prev => {
      const exists = prev.teachers.some(t => t.id === teacher.id);
      return {
        ...prev,
        teachers: exists
          ? prev.teachers.map(t => (t.id === teacher.id ? teacher : t))
          : [teacher, ...prev.teachers],
      };
    });
    addToast('success', 'Docente Registrado', `${teacher.lastName}, ${teacher.firstName} guardado.`);
    logAudit('GUARDAR_DOCENTE', 'Docentes', `Profesor ${teacher.code} actualizado`);
  };

  const deleteTeacher = (teacherId: string) => {
    setDbState(prev => ({
      ...prev,
      teachers: prev.teachers.filter(t => t.id !== teacherId),
    }));
    addToast('warning', 'Docente Retirado', 'Docente eliminado de la nómina.');
  };

  const saveClassroom = (classroom: Classroom) => {
    setDbState(prev => {
      const exists = prev.classrooms.some(c => c.id === classroom.id);
      return {
        ...prev,
        classrooms: exists
          ? prev.classrooms.map(c => (c.id === classroom.id ? classroom : c))
          : [...prev.classrooms, classroom],
      };
    });
    addToast('success', 'Aula Actualizada', `Salón ${classroom.name} registrado.`);
  };

  const deleteClassroom = (classroomId: string) => {
    setDbState(prev => ({
      ...prev,
      classrooms: prev.classrooms.filter(c => c.id !== classroomId),
    }));
    addToast('warning', 'Aula Eliminada', 'Espacio eliminado del catálogo.');
  };

  const saveCourse = (course: Course) => {
    setDbState(prev => {
      const exists = prev.courses.some(c => c.id === course.id);
      return {
        ...prev,
        courses: exists
          ? prev.courses.map(c => (c.id === course.id ? course : c))
          : [...prev.courses, course],
      };
    });
    addToast('success', 'Asignatura Guardada', `Curso ${course.name} actualizado.`);
  };

  const deleteCourse = (courseId: string) => {
    setDbState(prev => ({
      ...prev,
      courses: prev.courses.filter(c => c.id !== courseId),
    }));
    addToast('warning', 'Curso Eliminado', 'Asignatura retirada de la malla curricular.');
  };

  const saveEnrollment = (enrollment: Enrollment) => {
    setDbState(prev => {
      const exists = prev.enrollments.some(e => e.id === enrollment.id);
      return {
        ...prev,
        enrollments: exists
          ? prev.enrollments.map(e => (e.id === enrollment.id ? enrollment : e))
          : [enrollment, ...prev.enrollments],
      };
    });
    addToast('success', 'Matrícula Procesada', `Constancia N° ${enrollment.code} emitida.`);
    logAudit('MATRICULA_PROCESADA', 'Matrículas', `Matrícula ${enrollment.code}`);
  };

  const saveScheduleSlot = (slot: ScheduleSlot) => {
    setDbState(prev => {
      const exists = prev.schedules.some(s => s.id === slot.id);
      return {
        ...prev,
        schedules: exists
          ? prev.schedules.map(s => (s.id === slot.id ? slot : s))
          : [...prev.schedules, slot],
      };
    });
    addToast('success', 'Horario Asignado', 'Bloque de clase guardado en el cronograma.');
  };

  const deleteScheduleSlot = (slotId: string) => {
    setDbState(prev => ({
      ...prev,
      schedules: prev.schedules.filter(s => s.id !== slotId),
    }));
    addToast('info', 'Horario Removido', 'Bloque de clase eliminado.');
  };

  const recordAttendanceBatch = (records: AttendanceRecord[]) => {
    setDbState(prev => {
      const filtered = prev.attendances.filter(
        a => !records.some(r => r.date === a.date && r.courseId === a.courseId && r.studentId === a.studentId)
      );
      return {
        ...prev,
        attendances: [...records, ...filtered],
      };
    });

    const absents = records.filter(r => r.status === 'ausente');
    if (absents.length > 0) {
      triggerPushAlert(
        '⚠️ Alerta de Inasistencia',
        `Se han registrado ${absents.length} faltas no justificadas el día de hoy. Notificaciones automáticas despachadas a apoderados.`,
        true
      );
    } else {
      addToast('success', 'Asistencia Registrada', `Control de asistencia guardado para ${records.length} estudiantes.`);
    }
  };

  const saveGrade = (grade: GradeRecord) => {
    setDbState(prev => {
      const exists = prev.grades.some(g => g.id === grade.id);
      return {
        ...prev,
        grades: exists
          ? prev.grades.map(g => (g.id === grade.id ? grade : g))
          : [grade, ...prev.grades],
      };
    });
    addToast('success', 'Nota Asentada', `Calificación guardada con promedio: ${grade.finalScore.toFixed(1)}`);
    logAudit('REGISTRO_NOTA', 'Calificaciones', `Nota guardada para estudiante ${grade.studentId}`);
  };

  const recordPayment = (payment: PaymentRecord) => {
    setDbState(prev => {
      const exists = prev.payments.some(p => p.id === payment.id);
      return {
        ...prev,
        payments: exists
          ? prev.payments.map(p => (p.id === payment.id ? payment : p))
          : [payment, ...prev.payments],
      };
    });
    addToast('success', 'Pago Registrado', `Recibo N° ${payment.receiptNumber} por ${dbState.config.currencySymbol} ${payment.amount.toFixed(2)} emitido.`);
    logAudit('EMISION_RECIBO_PAGO', 'Pagos', `Recibo ${payment.receiptNumber} por ${payment.amount}`);
  };

  const createAnnouncement = (announcement: Announcement, sendPush: boolean = true) => {
    setDbState(prev => ({
      ...prev,
      announcements: [announcement, ...prev.announcements],
    }));

    if (sendPush) {
      triggerPushAlert(
        `📢 ${announcement.title}`,
        announcement.content.slice(0, 120) + '...',
        announcement.priority === 'alta'
      );
    }
    addToast('success', 'Comunicado Publicado', 'El aviso ha sido difundido a la comunidad escolar.');
  };

  const saveCustomRole = (role: CustomRole) => {
    setDbState(prev => {
      const exists = prev.roles.some(r => r.id === role.id);
      return {
        ...prev,
        roles: exists
          ? prev.roles.map(r => (r.id === role.id ? role : r))
          : [...prev.roles, role],
      };
    });
    addToast('success', 'Rol de Seguridad Guardado', `Perfil de permisos para ${role.name} actualizado.`);
  };

  const saveUserAccount = (user: UserAccount) => {
    setDbState(prev => {
      const exists = prev.users.some(u => u.id === user.id);
      return {
        ...prev,
        users: exists
          ? prev.users.map(u => (u.id === user.id ? user : u))
          : [...prev.users, user],
      };
    });
    addToast('success', 'Cuenta de Usuario', `Usuario ${user.name} guardado con éxito.`);
  };

  const markNotificationRead = (id: string) => {
    setDbState(prev => ({
      ...prev,
      notifications: prev.notifications.map(n => (n.id === id ? { ...n, read: true } : n)),
    }));
  };

  const clearAllNotifications = () => {
    setDbState(prev => ({
      ...prev,
      notifications: [],
    }));
    addToast('info', 'Notificaciones Limpiadas', 'Bandeja de alertas vacía.');
  };

  const exportDatabaseJSON = () => {
    StorageService.exportJSON(dbState);
    addToast('success', 'Copia de Seguridad Lista', 'Archivo JSON generado y descargado.');
    logAudit('BACKUP_JSON', 'Configuración', 'Descarga de respaldo total de la base de datos');
  };

  const exportDatabaseSQL = () => {
    StorageService.exportSQL(dbState);
    addToast('success', 'Migración Cloud SQL Lista', 'Script SQL para PostgreSQL/Cloud SQL descargado.');
    logAudit('MIGRACION_SQL_EXPORT', 'Configuración', 'Generación de dump SQL de base de datos');
  };

  const importDatabaseJSON = (data: DatabaseState) => {
    StorageService.saveState(data);
    setDbState(data);
    addToast('success', 'Restauración Exitosa', 'Base de datos restaurada correctamente desde el archivo.');
    logAudit('RESTAURACION_BACKUP', 'Configuración', 'Base de datos restaurada desde archivo externo');
  };

  const resetDatabase = () => {
    const fresh = StorageService.resetToDefault();
    setDbState(fresh);
    addToast('warning', 'Base de Datos Reiniciada', 'Los datos de fábrica fueron restablecidos.');
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        currentRole,
        setCurrentUser,
        switchRole,
        canAccessModule,
        activeModule,
        setActiveModule,
        config: dbState.config,
        updateConfig,
        users: dbState.users,
        roles: dbState.roles,
        students: dbState.students,
        teachers: dbState.teachers,
        classrooms: dbState.classrooms,
        courses: dbState.courses,
        enrollments: dbState.enrollments,
        schedules: dbState.schedules,
        attendances: dbState.attendances,
        grades: dbState.grades,
        payments: dbState.payments,
        announcements: dbState.announcements,
        notifications: dbState.notifications,
        auditLogs: dbState.auditLogs,
        saveStudent,
        deleteStudent,
        saveTeacher,
        deleteTeacher,
        saveClassroom,
        deleteClassroom,
        saveCourse,
        deleteCourse,
        saveEnrollment,
        saveScheduleSlot,
        deleteScheduleSlot,
        recordAttendanceBatch,
        saveGrade,
        recordPayment,
        createAnnouncement,
        saveCustomRole,
        saveUserAccount,
        markNotificationRead,
        clearAllNotifications,
        triggerPushAlert,
        runPeriodicAutomatedReport,
        toasts,
        addToast,
        removeToast,
        encryptionUnlocked,
        setEncryptionUnlocked,
        exportDatabaseJSON,
        exportDatabaseSQL,
        importDatabaseJSON,
        resetDatabase,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
