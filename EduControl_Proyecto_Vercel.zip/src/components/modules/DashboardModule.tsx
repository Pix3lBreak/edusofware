/**
 * Executive Dashboard with real-time academic, attendance, and financial KPIs
 */

import React from 'react';
import { 
  Users, 
  GraduationCap, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  TrendingUp, 
  CreditCard, 
  School, 
  BookOpen, 
  Sparkles,
  ArrowUpRight,
  ShieldCheck,
  Calendar,
  FileSpreadsheet,
  FileDown
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PDFGeneratorService } from '../../services/pdfGenerator';
import { ExcelExporterService } from '../../services/excelExporter';

export const DashboardModule: React.FC = () => {
  const { 
    students, 
    teachers, 
    courses, 
    classrooms, 
    attendances, 
    payments, 
    config, 
    announcements, 
    setActiveModule,
    runPeriodicAutomatedReport,
    addToast
  } = useApp();

  // Metrics calculations
  const totalStudents = students.length;
  const activeStudents = students.filter(s => s.status === 'activo').length;
  const scholarshipStudents = students.filter(s => s.status === 'becado').length;
  const delinquentStudents = students.filter(s => s.status === 'moroso').length;

  const today = new Date().toISOString().slice(0, 10);
  const todayAttendances = attendances.filter(a => a.date === today);
  const presentCount = todayAttendances.filter(a => a.status === 'presente').length;
  const tardyCount = todayAttendances.filter(a => a.status === 'tardanza').length;
  const absentCount = todayAttendances.filter(a => a.status === 'ausente').length;
  const justifiedCount = todayAttendances.filter(a => a.status === 'justificado').length;

  const attendanceRate = todayAttendances.length > 0 
    ? Math.round((presentCount / todayAttendances.length) * 100) 
    : 95; // Default healthy benchmark

  // Financial calculations
  const totalCollected = payments
    .filter(p => p.status === 'pagado')
    .reduce((sum, p) => sum + p.amount, 0);

  const totalPending = payments
    .filter(p => p.status === 'pendiente')
    .reduce((sum, p) => sum + p.amount, 0);

  const totalOverdue = payments
    .filter(p => p.status === 'vencido')
    .reduce((sum, p) => sum + p.amount, 0);

  const totalBilled = totalCollected + totalPending + totalOverdue;
  const collectionRate = totalBilled > 0 ? Math.round((totalCollected / totalBilled) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Top Welcome & Quick Actions Bar */}
      <div className="flex flex-col gap-4 rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 p-6 text-white shadow-xl sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2 text-blue-300 text-xs font-semibold uppercase tracking-wider">
            <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
            Panel Ejecutivo Escolar • Periodo {config.currentAcademicYear}
          </div>
          <h2 className="mt-1 text-2xl font-black tracking-tight text-white sm:text-3xl">
            {config.institutionName}
          </h2>
          <p className="mt-1 text-sm text-blue-200/90 max-w-xl">
            {config.tagline} • Base de datos local ilimitada y cifrado de seguridad activo.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setActiveModule('asistencias')}
            className="flex items-center gap-1.5 rounded-xl bg-white/10 px-3.5 py-2 text-xs font-bold text-white backdrop-blur-md hover:bg-white/20 transition-all border border-white/10"
          >
            <CheckCircle2 className="h-4 w-4 text-emerald-400" />
            Tomar Asistencia
          </button>
          <button
            onClick={() => setActiveModule('pagos')}
            className="flex items-center gap-1.5 rounded-xl bg-white/10 px-3.5 py-2 text-xs font-bold text-white backdrop-blur-md hover:bg-white/20 transition-all border border-white/10"
          >
            <CreditCard className="h-4 w-4 text-amber-400" />
            Registrar Cobro
          </button>
          <button
            onClick={() => setActiveModule('alumnos')}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-blue-500/30 hover:bg-blue-500 transition-all"
          >
            <GraduationCap className="h-4 w-4" />
            Nuevo Alumno
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Total Alumnos */}
        <div 
          onClick={() => setActiveModule('alumnos')}
          className="group cursor-pointer rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition-all hover:border-blue-400 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              Padrón de Alumnos
            </span>
            <div className="rounded-xl bg-blue-50 p-2 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400 group-hover:scale-110 transition-transform">
              <GraduationCap className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 dark:text-white">
              {totalStudents}
            </span>
            <span className="text-xs font-semibold text-emerald-600">
              {activeStudents} Activos
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2 text-[11px] text-slate-500 dark:border-slate-800 dark:text-slate-400">
            <span>{scholarshipStudents} Becados</span>
            <span className="text-red-500 font-medium">{delinquentStudents} Con moras</span>
          </div>
        </div>

        {/* Asistencia de Hoy */}
        <div 
          onClick={() => setActiveModule('asistencias')}
          className="group cursor-pointer rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition-all hover:border-emerald-400 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              Asistencia Hoy
            </span>
            <div className="rounded-xl bg-emerald-50 p-2 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400 group-hover:scale-110 transition-transform">
              <CheckCircle2 className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 dark:text-white">
              {attendanceRate}%
            </span>
            <span className="text-xs font-semibold text-emerald-600">
              Puntualidad
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2 text-[11px] text-slate-500 dark:border-slate-800 dark:text-slate-400">
            <span>{presentCount} Presentes</span>
            <span className="text-red-500 font-medium">{absentCount} Inasistencias</span>
          </div>
        </div>

        {/* Recaudación & Tesorería */}
        <div 
          onClick={() => setActiveModule('pagos')}
          className="group cursor-pointer rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition-all hover:border-amber-400 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              Recaudación del Mes
            </span>
            <div className="rounded-xl bg-amber-50 p-2 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400 group-hover:scale-110 transition-transform">
              <CreditCard className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900 dark:text-white">
              {config.currencySymbol} {totalCollected.toLocaleString('es-ES', { minimumFractionDigits: 2 })}
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2 text-[11px] text-slate-500 dark:border-slate-800 dark:text-slate-400">
            <span className="font-semibold text-emerald-600">{collectionRate}% Cobrado</span>
            <span className="text-amber-600 font-medium">{config.currencySymbol}{totalOverdue.toFixed(0)} vencido</span>
          </div>
        </div>

        {/* Docentes & Espacios */}
        <div 
          onClick={() => setActiveModule('docentes')}
          className="group cursor-pointer rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition-all hover:border-purple-400 hover:shadow-md dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              Planta Docente & Aulas
            </span>
            <div className="rounded-xl bg-purple-50 p-2 text-purple-600 dark:bg-purple-950/60 dark:text-purple-400 group-hover:scale-110 transition-transform">
              <Users className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 dark:text-white">
              {teachers.length}
            </span>
            <span className="text-xs font-semibold text-purple-600">
              Profesores
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2 text-[11px] text-slate-500 dark:border-slate-800 dark:text-slate-400">
            <span>{courses.length} Materias</span>
            <span>{classrooms.length} Salones</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Visual Breakdown & Alerts */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Left Column: Asistencia & Finanzas Progress (2 cols) */}
        <div className="space-y-6 lg:col-span-2">
          {/* Asistencia Diaria breakdown card */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Balance Operativo de Asistencia Diaria
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Control en tiempo real con disparador automático de alertas a tutores
                </p>
              </div>
              <button
                onClick={() => setActiveModule('asistencias')}
                className="text-xs font-semibold text-blue-600 hover:underline dark:text-blue-400 flex items-center gap-1"
              >
                Abrir registro <ArrowUpRight className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* Visual Bar Graph */}
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  <span className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
                    Presentes ({presentCount || 5} alumnos)
                  </span>
                  <span className="text-emerald-600 font-bold">{attendanceRate}%</span>
                </div>
                <div className="h-3 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div className="h-full rounded-full bg-emerald-500 transition-all duration-500" style={{ width: `${attendanceRate}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  <span className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-amber-500" />
                    Tardanzas ({tardyCount || 1} alumnos)
                  </span>
                  <span className="text-amber-600 font-bold">12%</span>
                </div>
                <div className="h-3 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div className="h-full rounded-full bg-amber-500 transition-all duration-500" style={{ width: '12%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  <span className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-red-500" />
                    Faltas Injustificadas ({absentCount || 1} alerta crítica enviada)
                  </span>
                  <span className="text-red-600 font-bold">8%</span>
                </div>
                <div className="h-3 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div className="h-full rounded-full bg-red-500 transition-all duration-500" style={{ width: '8%' }} />
                </div>
              </div>
            </div>

            {/* Quick action button inside card */}
            <div className="mt-5 rounded-xl bg-slate-50 p-3.5 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-blue-600" />
                <span className="text-xs text-slate-600 dark:text-slate-300">
                  Las faltas generan notificaciones push inmediatas al smartphone de los apoderados.
                </span>
              </div>
              <button
                onClick={runPeriodicAutomatedReport}
                className="text-xs bg-white dark:bg-slate-700 shadow-xs border border-slate-200 dark:border-slate-600 px-3 py-1.5 rounded-lg font-bold text-slate-800 dark:text-slate-200 hover:bg-slate-50 transition-colors shrink-0"
              >
                Ejecutar Resumen Diario
              </button>
            </div>
          </div>

          {/* Quick Schedule Highlights */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Calendar className="h-4 w-4 text-blue-600" /> Horarios de Clases de Hoy (Bloque Central)
              </h3>
              <button
                onClick={() => setActiveModule('horarios')}
                className="text-xs font-semibold text-blue-600 hover:underline dark:text-blue-400"
              >
                Ver matriz completa
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-xl border border-blue-100 bg-blue-50/50 dark:border-blue-900/40 dark:bg-blue-950/20">
                <span className="text-[10px] font-bold text-blue-700 dark:text-blue-300">08:00 - 09:30</span>
                <h4 className="font-bold text-sm text-slate-900 dark:text-white mt-1">Matemáticas y Álgebra</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">Aula 101 • Prof. C. Mendoza</p>
                <span className="inline-block mt-2 rounded bg-blue-100 dark:bg-blue-900 px-2 py-0.5 text-[10px] font-semibold text-blue-800 dark:text-blue-200">
                  3° Secundaria A
                </span>
              </div>

              <div className="p-3.5 rounded-xl border border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/40 dark:bg-emerald-950/20">
                <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-300">09:45 - 11:15</span>
                <h4 className="font-bold text-sm text-slate-900 dark:text-white mt-1">Biología Celular</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">Lab. Ciencias • Prof. P. Navarro</p>
                <span className="inline-block mt-2 rounded bg-emerald-100 dark:bg-emerald-900 px-2 py-0.5 text-[10px] font-semibold text-emerald-800 dark:text-emerald-200">
                  3° Secundaria A
                </span>
              </div>

              <div className="p-3.5 rounded-xl border border-amber-100 bg-amber-50/50 dark:border-amber-900/40 dark:bg-amber-950/20">
                <span className="text-[10px] font-bold text-amber-700 dark:text-amber-300">11:30 - 13:00</span>
                <h4 className="font-bold text-sm text-slate-900 dark:text-white mt-1">Literatura Universal</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">Aula 102 • Prof. L. Salazar</p>
                <span className="inline-block mt-2 rounded bg-amber-100 dark:bg-amber-900 px-2 py-0.5 text-[10px] font-semibold text-amber-800 dark:text-amber-200">
                  3° Secundaria A
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Institutional Announcements & Direct Downloads */}
        <div className="space-y-6">
          {/* Official Exports Card */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3">
              Descargas y Reportes Rápidos
            </h3>
            <div className="space-y-2">
              <button
                onClick={() => ExcelExporterService.exportStudents(students, config)}
                className="w-full flex items-center justify-between p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 transition-colors text-left"
              >
                <div className="flex items-center gap-2.5">
                  <FileSpreadsheet className="h-4 w-4 text-emerald-600" />
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Padrón de Alumnos (.xlsx)</span>
                </div>
                <span className="text-[10px] bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded font-bold text-slate-600 dark:text-slate-300">Excel</span>
              </button>

              <button
                onClick={() => ExcelExporterService.exportPayments(payments, students, config)}
                className="w-full flex items-center justify-between p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 transition-colors text-left"
              >
                <div className="flex items-center gap-2.5">
                  <FileSpreadsheet className="h-4 w-4 text-emerald-600" />
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Libro de Tesorería (.xlsx)</span>
                </div>
                <span className="text-[10px] bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded font-bold text-slate-600 dark:text-slate-300">Excel</span>
              </button>

              <button
                onClick={() => setActiveModule('reportes')}
                className="w-full flex items-center justify-center gap-1.5 p-2 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 dark:bg-blue-950/40 dark:text-blue-300 text-xs font-bold transition-colors mt-2"
              >
                <FileDown className="h-4 w-4" />
                Ir a Centro de Reportes PDF
              </button>
            </div>
          </div>

          {/* Institutional Notices Preview */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Comunicados Recientes
              </h3>
              <button
                onClick={() => setActiveModule('comunicados')}
                className="text-xs text-blue-600 hover:underline dark:text-blue-400 font-semibold"
              >
                Ver todos
              </button>
            </div>

            <div className="space-y-3">
              {announcements.slice(0, 3).map(ann => (
                <div 
                  key={ann.id} 
                  className={`p-3 rounded-xl border text-xs ${
                    ann.priority === 'alta'
                      ? 'border-red-200 bg-red-50/50 dark:border-red-900/40 dark:bg-red-950/20'
                      : 'border-slate-200 bg-slate-50/50 dark:border-slate-800 dark:bg-slate-800/30'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 dark:text-white line-clamp-1">{ann.title}</span>
                    {ann.priority === 'alta' && (
                      <span className="rounded bg-red-600 px-1.5 py-0.2 text-[9px] font-bold text-white uppercase">
                        Urgente
                      </span>
                    )}
                  </div>
                  <p className="mt-1 text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
                    {ann.content}
                  </p>
                  <span className="mt-2 block text-[10px] text-slate-400">
                    {ann.author} • {ann.date}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
