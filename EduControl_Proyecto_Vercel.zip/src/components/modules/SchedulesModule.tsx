/**
 * Interactive Weekly Class Schedule Module with conflict detection
 */

import React, { useState } from 'react';
import { 
  CalendarClock, 
  Plus, 
  Trash2, 
  X, 
  AlertCircle, 
  BookOpen, 
  School, 
  User,
  Clock
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ScheduleSlot } from '../../types';

export const SchedulesModule: React.FC = () => {
  const { 
    schedules, 
    courses, 
    classrooms, 
    teachers, 
    saveScheduleSlot, 
    deleteScheduleSlot,
    addToast 
  } = useApp();

  const [selectedGrade, setSelectedGrade] = useState('3° Secundaria');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [newSlot, setNewSlot] = useState<Partial<ScheduleSlot>>({
    dayOfWeek: 1,
    startTime: '08:00',
    endTime: '09:30',
    courseId: courses[0]?.id || '',
    classroomId: classrooms[0]?.id || '',
    gradeLevel: '3° Secundaria',
    section: 'A',
  });

  const days = [
    { num: 1, name: 'Lunes' },
    { num: 2, name: 'Martes' },
    { num: 3, name: 'Miércoles' },
    { num: 4, name: 'Jueves' },
    { num: 5, name: 'Viernes' },
  ];

  const timeBlocks = [
    { start: '08:00', end: '09:30', label: 'Bloque 1 (08:00 - 09:30)' },
    { start: '09:45', end: '11:15', label: 'Bloque 2 (09:45 - 11:15)' },
    { start: '11:30', end: '13:00', label: 'Bloque 3 (11:30 - 13:00)' },
    { start: '13:15', end: '14:45', label: 'Bloque 4 (13:15 - 14:45)' },
  ];

  const courseMap = new Map(courses.map(c => [c.id, c]));
  const classroomMap = new Map(classrooms.map(c => [c.id, c]));
  const teacherMap = new Map(teachers.map(t => [t.id, t]));

  // Filter schedules for the active grade
  const gradeSchedules = schedules.filter(s => s.gradeLevel === selectedGrade);

  const handleAddSlot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSlot.courseId || !newSlot.classroomId) return;

    // Conflict detection: verify classroom isn't double-booked
    const classroomConflict = schedules.find(
      s => s.dayOfWeek === newSlot.dayOfWeek && 
           s.startTime === newSlot.startTime && 
           s.classroomId === newSlot.classroomId
    );

    if (classroomConflict) {
      addToast('error', 'Conflicto de Aula', `El aula ya se encuentra ocupada por otro grupo en este mismo horario.`);
      return;
    }

    const slot: ScheduleSlot = {
      id: `sch-${Date.now()}`,
      dayOfWeek: newSlot.dayOfWeek as 1 | 2 | 3 | 4 | 5,
      startTime: newSlot.startTime || '08:00',
      endTime: newSlot.endTime || '09:30',
      courseId: newSlot.courseId,
      classroomId: newSlot.classroomId,
      gradeLevel: newSlot.gradeLevel || selectedGrade,
      section: newSlot.section || 'A',
    };

    saveScheduleSlot(slot);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-black text-slate-900 dark:text-white sm:text-2xl flex items-center gap-2">
            <CalendarClock className="h-6 w-6 text-blue-600" /> Organización de Horarios de Clases
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Cuadrícula interactiva semanal con prevención automática de colisiones entre aulas y profesores.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <select
            value={selectedGrade}
            onChange={e => setSelectedGrade(e.target.value)}
            className="rounded-xl border border-slate-200 bg-white py-2 px-3 text-xs font-bold text-slate-800 dark:border-slate-800 dark:bg-slate-900 dark:text-white shadow-xs focus:outline-none"
          >
            <option value="3° Secundaria">3° Secundaria (A)</option>
            <option value="4° Secundaria">4° Secundaria (B)</option>
            <option value="1° Primaria">1° Primaria</option>
            <option value="2° Primaria">2° Primaria</option>
          </select>
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-md shadow-blue-500/20 hover:bg-blue-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            Asignar Bloque
          </button>
        </div>
      </div>

      {/* Weekly Interactive Timetable Grid */}
      <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-xs dark:border-slate-800 dark:bg-slate-900">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs min-w-[700px]">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 dark:bg-slate-800/60 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-bold uppercase text-[11px]">
                <th className="py-3 px-3 w-28 text-center border-r border-slate-200 dark:border-slate-800">
                  Horario
                </th>
                {days.map(d => (
                  <th key={d.num} className="py-3 px-3 text-center border-r last:border-r-0 border-slate-200 dark:border-slate-800">
                    {d.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {timeBlocks.map((block, bIdx) => (
                <tr key={bIdx} className="hover:bg-slate-50/30 dark:hover:bg-slate-800/20">
                  <td className="py-4 px-2 text-center font-bold text-slate-500 dark:text-slate-400 border-r border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30">
                    <div className="text-[11px] font-mono">{block.start}</div>
                    <div className="text-[10px] text-slate-400 font-normal">a {block.end}</div>
                  </td>

                  {days.map(d => {
                    const slot = gradeSchedules.find(
                      s => s.dayOfWeek === d.num && s.startTime === block.start
                    );

                    if (!slot) {
                      return (
                        <td 
                          key={d.num} 
                          className="py-3 px-2 text-center border-r last:border-r-0 border-slate-200 dark:border-slate-800"
                        >
                          <span className="text-[11px] text-slate-300 dark:text-slate-600 font-medium italic">
                            Libre / Estudio
                          </span>
                        </td>
                      );
                    }

                    const course = courseMap.get(slot.courseId);
                    const classroom = classroomMap.get(slot.classroomId);
                    const teacher = course ? teacherMap.get(course.teacherId) : null;

                    return (
                      <td 
                        key={d.num} 
                        className="py-2.5 px-2 border-r last:border-r-0 border-slate-200 dark:border-slate-800"
                      >
                        <div 
                          className="group relative rounded-xl p-3 border shadow-xs transition-all hover:shadow-md"
                          style={{
                            borderColor: course?.color ? `${course.color}40` : '#94a3b8',
                            backgroundColor: course?.color ? `${course.color}15` : '#f8fafc',
                          }}
                        >
                          <div className="flex items-start justify-between gap-1">
                            <span 
                              className="font-bold text-xs leading-tight line-clamp-1"
                              style={{ color: course?.color || '#1e293b' }}
                            >
                              {course?.name || 'Materia'}
                            </span>
                            <button
                              onClick={() => deleteScheduleSlot(slot.id)}
                              className="opacity-0 group-hover:opacity-100 p-0.5 text-slate-400 hover:text-red-600 transition-opacity"
                              title="Remover bloque"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </div>

                          <div className="mt-1.5 space-y-0.5 text-[10px] text-slate-600 dark:text-slate-300">
                            <div className="flex items-center gap-1 text-slate-500">
                              <School className="h-3 w-3" />
                              <span className="truncate">{classroom?.name || 'Aula'}</span>
                            </div>
                            <div className="flex items-center gap-1 text-slate-500">
                              <User className="h-3 w-3" />
                              <span className="truncate">{teacher ? `${teacher.firstName[0]}. ${teacher.lastName}` : 'Profesor'}</span>
                            </div>
                          </div>
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD SCHEDULE MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form 
            onSubmit={handleAddSlot}
            className="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden dark:bg-slate-900 border border-slate-200 dark:border-slate-800 animate-in zoom-in-95 duration-150"
          >
            <div className="bg-blue-600 p-5 text-white flex items-center justify-between">
              <h3 className="font-bold text-base flex items-center gap-2">
                <CalendarClock className="h-5 w-5" /> Asignar Clase al Horario
              </h3>
              <button 
                type="button" 
                onClick={() => setIsModalOpen(false)}
                className="text-white/70 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="p-6 space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Día de la Semana</label>
                <select
                  value={newSlot.dayOfWeek}
                  onChange={e => setNewSlot({ ...newSlot, dayOfWeek: parseInt(e.target.value) as any })}
                  className="w-full rounded-xl border border-slate-300 p-2 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-semibold"
                >
                  <option value={1}>Lunes</option>
                  <option value={2}>Martes</option>
                  <option value={3}>Miércoles</option>
                  <option value={4}>Jueves</option>
                  <option value={5}>Viernes</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Bloque Horario</label>
                <select
                  value={newSlot.startTime}
                  onChange={e => {
                    const block = timeBlocks.find(b => b.start === e.target.value);
                    setNewSlot({
                      ...newSlot,
                      startTime: block?.start || '08:00',
                      endTime: block?.end || '09:30',
                    });
                  }}
                  className="w-full rounded-xl border border-slate-300 p-2 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-semibold"
                >
                  {timeBlocks.map((b, i) => (
                    <option key={i} value={b.start}>
                      {b.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Asignatura / Curso</label>
                <select
                  value={newSlot.courseId}
                  onChange={e => setNewSlot({ ...newSlot, courseId: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  {courses.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.gradeLevel})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Aula / Salón Asignado</label>
                <select
                  value={newSlot.classroomId}
                  onChange={e => setNewSlot({ ...newSlot, classroomId: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  {classrooms.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} - Cap: {c.capacity}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="border-t border-slate-200 bg-slate-50 px-6 py-3.5 dark:border-slate-800 dark:bg-slate-800/60 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl font-bold transition-colors"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-md shadow-blue-500/20 transition-colors"
              >
                Guardar Bloque
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
