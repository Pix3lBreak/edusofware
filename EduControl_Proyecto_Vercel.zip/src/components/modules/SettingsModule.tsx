/**
 * Institutional Settings & Limitless Free Local Database Engine
 */

import React, { useState } from 'react';
import { 
  Settings, 
  Database, 
  Download, 
  Upload, 
  RotateCcw, 
  Save, 
  Server, 
  Globe, 
  CheckCircle2, 
  ShieldCheck, 
  HardDrive,
  FileCode2,
  FileJson
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { SchoolConfig } from '../../types';
import { ZipExporterService } from '../../services/zipExporter';

export const SettingsModule: React.FC = () => {
  const { 
    config, 
    updateConfig, 
    exportDatabaseJSON, 
    exportDatabaseSQL, 
    importDatabaseJSON, 
    resetDatabase,
    students,
    teachers,
    payments,
    grades,
    addToast
  } = useApp();

  const [formData, setFormData] = useState<SchoolConfig>({ ...config });
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  const handleSaveParams = (e: React.FormEvent) => {
    e.preventDefault();
    updateConfig(formData);
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (json.config && json.students) {
          importDatabaseJSON(json);
        } else {
          addToast('error', 'Formato Inválido', 'El archivo no contiene una estructura válida de EduControl.');
        }
      } catch (err) {
        addToast('error', 'Error de Lectura', 'No se pudo interpretar el archivo JSON de respaldo.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-black text-slate-900 dark:text-white sm:text-2xl flex items-center gap-2">
          <Settings className="h-6 w-6 text-blue-600" /> Parámetros del Sistema y Base de Datos
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Personalización institucional, escala académica, copias de seguridad sin costo y exportación a la nube.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* COLUMN 1 & 2: INSTITUTIONAL CONFIGURATION FORM */}
        <form onSubmit={handleSaveParams} className="lg:col-span-2 space-y-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white border-b border-slate-100 pb-2 dark:border-slate-800">
              Datos Generales de la Institución
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Nombre Oficial del Colegio / Instituto *
                </label>
                <input
                  type="text"
                  required
                  value={formData.institutionName}
                  onChange={e => setFormData({ ...formData, institutionName: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2.5 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Lema o Visión Institucional
                </label>
                <input
                  type="text"
                  value={formData.tagline}
                  onChange={e => setFormData({ ...formData, tagline: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2.5 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Código Modular / Registro Educativo
                </label>
                <input
                  type="text"
                  value={formData.institutionCode}
                  onChange={e => setFormData({ ...formData, institutionCode: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2.5 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Año Lectivo Vigente
                </label>
                <input
                  type="text"
                  value={formData.currentAcademicYear}
                  onChange={e => setFormData({ ...formData, currentAcademicYear: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2.5 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-bold text-blue-600"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Dirección del Campus o Sede Central
                </label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2.5 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Teléfono / Central Telefónica
                </label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2.5 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Correo Electrónico de Contacto
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2.5 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Academic & Financial Parameters */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white border-b border-slate-100 pb-2 dark:border-slate-800">
              Parámetros de Calificación y Moneda
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Símbolo de Moneda
                </label>
                <input
                  type="text"
                  value={formData.currencySymbol}
                  onChange={e => setFormData({ ...formData, currencySymbol: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 p-2.5 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-bold text-center"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Escala de Calificaciones
                </label>
                <select
                  value={formData.gradingScale}
                  onChange={e => setFormData({ ...formData, gradingScale: e.target.value as any })}
                  className="w-full rounded-xl border border-slate-300 p-2.5 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-bold"
                >
                  <option value="0-20">Escala 0 a 20 (Perú / Latinoamérica)</option>
                  <option value="0-10">Escala 0 a 10 (España / México / Colombia)</option>
                  <option value="0-100">Escala 0 a 100 Porcentual</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Nota Mínima Aprobatoria
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={formData.minPassingGrade}
                  onChange={e => setFormData({ ...formData, minPassingGrade: parseFloat(e.target.value) || 11 })}
                  className="w-full rounded-xl border border-slate-300 p-2.5 dark:border-slate-700 dark:bg-slate-800 dark:text-white font-bold text-center"
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-md shadow-blue-500/20 transition-colors"
              >
                <Save className="h-4 w-4" /> Guardar Parámetros
              </button>
            </div>
          </div>
        </form>

        {/* COLUMN 3: DATABASE ENGINE, BACKUP & CLOUD HOSTING MIGRATION */}
        <div className="space-y-6">
          {/* Real Free Database Card */}
          <div className="rounded-2xl border border-emerald-200 bg-white p-5 shadow-xs dark:border-emerald-900/40 dark:bg-slate-900 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="h-5 w-5 text-emerald-600" />
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">Motor de Base de Datos</h3>
              </div>
              <span className="bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full">
                Gratis / Ilimitada
              </span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              La base de datos opera localmente en tu navegador sin requerir suscripciones pagas ni servidores costosos.
            </p>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-500 dark:text-slate-400">
                <span>Alumnos Registrados:</span>
                <span className="font-bold text-slate-900 dark:text-white">{students.length}</span>
              </div>
              <div className="flex justify-between text-slate-500 dark:text-slate-400">
                <span>Profesores en Nómina:</span>
                <span className="font-bold text-slate-900 dark:text-white">{teachers.length}</span>
              </div>
              <div className="flex justify-between text-slate-500 dark:text-slate-400">
                <span>Recibos Emitidos:</span>
                <span className="font-bold text-slate-900 dark:text-white">{payments.length}</span>
              </div>
              <div className="flex justify-between text-slate-500 dark:text-slate-400">
                <span>Calificaciones Asentadas:</span>
                <span className="font-bold text-slate-900 dark:text-white">{grades.length}</span>
              </div>
            </div>

            {/* Backup & Export Actions */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={async () => {
                  try {
                    addToast('info', 'Generando ZIP', 'Empaquetando todos los archivos del proyecto para Vercel...');
                    await ZipExporterService.downloadProjectZip();
                    addToast('success', 'Descarga Completada', 'Archivo ZIP del proyecto generado con éxito.');
                  } catch (e) {
                    addToast('error', 'Error al empaquetar', 'No se pudo generar el archivo ZIP.');
                  }
                }}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs py-2.5 px-3 rounded-xl shadow-md shadow-emerald-500/20 transition-all"
              >
                <Download className="h-4 w-4" />
                Descargar Proyecto (.zip) para Vercel
              </button>

              <button
                type="button"
                onClick={exportDatabaseJSON}
                className="w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs py-2 px-3 rounded-xl transition-colors dark:bg-slate-700 dark:hover:bg-slate-600"
              >
                <FileJson className="h-4 w-4 text-amber-400" />
                Exportar Copia de Base de Datos (.json)
              </button>

              <button
                type="button"
                onClick={exportDatabaseSQL}
                className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2 px-3 rounded-xl shadow-xs transition-colors"
                title="Genera script .sql compatible con PostgreSQL, Supabase, Neon o Cloud SQL"
              >
                <FileCode2 className="h-4 w-4 text-white" />
                Exportar Script SQL para Cloud (.sql)
              </button>

              <label className="w-full flex items-center justify-center gap-2 border border-slate-300 bg-white hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs py-2 px-3 rounded-xl cursor-pointer transition-colors">
                <Upload className="h-4 w-4 text-emerald-600" />
                Restaurar Backup desde Archivo
                <input type="file" accept=".json" onChange={handleFileImport} className="hidden" />
              </label>
            </div>
          </div>

          {/* Cloud Deployment Instructions */}
          <div className="rounded-2xl border border-blue-200 bg-blue-50/50 p-5 shadow-xs dark:border-blue-900/40 dark:bg-slate-900 space-y-3">
            <h4 className="font-bold text-xs text-blue-950 dark:text-blue-200 flex items-center gap-2">
              <Globe className="h-4 w-4 text-blue-600" /> ¿Dónde están mis archivos y cómo subirlos a Vercel?
            </h4>
            <div className="text-[11px] text-slate-700 dark:text-slate-300 space-y-2 leading-relaxed">
              <p>
                <strong>1. Descarga directa en 1 clic:</strong> Presiona el botón verde de arriba <em>"Descargar Proyecto (.zip) para Vercel"</em> para obtener todo el código fuente empaquetado.
              </p>
              <p>
                <strong>2. Desde la barra de AI Studio:</strong> En la parte superior de Google AI Studio encontrarás el botón <strong>"Export" / "Download"</strong> o el ícono de <strong>GitHub</strong> para conectar tu cuenta o descargar el código.
              </p>
              <p>
                <strong>3. Subir a Vercel:</strong> Descomprime el archivo y corre <code className="bg-white dark:bg-slate-800 px-1.5 py-0.5 rounded border border-blue-200 dark:border-slate-700 font-mono text-blue-600">vercel</code> en la terminal, o sube la carpeta a un repositorio de GitHub y conéctalo en <a href="https://vercel.com/new" target="_blank" rel="noreferrer" className="text-blue-600 underline font-semibold">vercel.com/new</a>.
              </p>
            </div>
          </div>

          {/* Factory Reset Danger Zone */}
          <div className="rounded-2xl border border-red-200 bg-red-50/40 p-5 dark:border-red-900/40 dark:bg-red-950/20 space-y-2">
            <h4 className="font-bold text-xs text-red-800 dark:text-red-300">
              Restablecer Datos de Demostración
            </h4>
            <p className="text-[11px] text-red-600 dark:text-red-400 leading-relaxed">
              Restaura la base de datos a sus valores iniciales de fábrica con estudiantes y docentes de prueba.
            </p>
            <button
              type="button"
              onClick={() => {
                if (confirm('¿Restablecer la base de datos completa con los datos de fábrica?')) {
                  resetDatabase();
                }
              }}
              className="text-xs bg-red-600 hover:bg-red-700 text-white font-bold py-1.5 px-3 rounded-lg transition-colors flex items-center gap-1"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Restablecer de Fábrica
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
