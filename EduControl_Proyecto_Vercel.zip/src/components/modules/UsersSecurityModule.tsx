/**
 * Security, Custom Roles & E2EE Encryption Management Module
 */

import React, { useState, useEffect } from 'react';
import { 
  Users, 
  ShieldCheck, 
  Lock, 
  Unlock, 
  Key, 
  Plus, 
  Search, 
  Check, 
  X, 
  Eye, 
  AlertCircle, 
  ShieldAlert,
  History,
  FileKey
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CustomRole, UserAccount, UserRole } from '../../types';
import { CryptoService } from '../../services/crypto';

export const UsersSecurityModule: React.FC = () => {
  const { 
    users, 
    roles, 
    auditLogs, 
    saveCustomRole, 
    saveUserAccount, 
    encryptionUnlocked, 
    setEncryptionUnlocked, 
    addToast 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'usuarios' | 'roles' | 'cifrado' | 'auditoria'>('usuarios');
  const [searchUser, setSearchUser] = useState('');
  
  // Custom role editor state
  const [selectedRole, setSelectedRole] = useState<CustomRole>(roles[0]);
  const [isEditingRole, setIsEditingRole] = useState(false);

  // E2EE testing state
  const [masterKey, setMasterKey] = useState(CryptoService.getPassphrase());
  const [fingerprint, setFingerprint] = useState('');
  const [testPlaintext, setTestPlaintext] = useState('Registro Médico Confidencial: El alumno presenta cuadro de asma leve.');
  const [testCiphertext, setTestCiphertext] = useState('');
  const [testDecrypted, setTestDecrypted] = useState('');

  // User modal
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<Partial<UserAccount>>({});

  useEffect(() => {
    CryptoService.getFingerprint(masterKey).then(fp => setFingerprint(fp));
  }, [masterKey]);

  const handleTestEncrypt = async () => {
    const cipher = await CryptoService.encrypt(testPlaintext, masterKey);
    setTestCiphertext(cipher);
    const decrypted = await CryptoService.decrypt<string>(cipher, masterKey);
    setTestDecrypted(decrypted || 'Error al descifrar');
  };

  const handleSaveMasterKey = () => {
    CryptoService.setPassphrase(masterKey);
    addToast('success', 'Llave Maestra Actualizada', 'La clave de cifrado E2EE institucional fue actualizada.');
  };

  const handleTogglePermission = (module: string, perm: 'create' | 'read' | 'update' | 'delete') => {
    if (!selectedRole || selectedRole.isSystem) return;

    setSelectedRole(prev => ({
      ...prev,
      permissions: {
        ...prev.permissions,
        [module]: {
          ...prev.permissions[module],
          [perm]: !prev.permissions[module]?.[perm],
        },
      },
    }));
  };

  const handleSaveRole = () => {
    if (selectedRole.isSystem) {
      addToast('warning', 'Rol Protegido', 'Los roles predefinidos del sistema no pueden modificarse.');
      return;
    }
    saveCustomRole(selectedRole);
  };

  const handleOpenNewUser = () => {
    setEditingUser({
      id: `usr-${Date.now()}`,
      name: '',
      email: '',
      role: 'docente',
      status: 'activo',
      phone: '',
    });
    setIsUserModalOpen(true);
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser.name || !editingUser.email) return;
    saveUserAccount(editingUser as UserAccount);
    setIsUserModalOpen(false);
  };

  const modulesList = [
    { key: 'alumnos', label: 'Alumnos y Expedientes' },
    { key: 'docentes', label: 'Docentes y Personal' },
    { key: 'aulas', label: 'Aulas y Espacios' },
    { key: 'cursos', label: 'Materia y Asignaturas' },
    { key: 'matriculas', label: 'Matrículas e Inscripciones' },
    { key: 'horarios', label: 'Horarios de Clases' },
    { key: 'asistencias', label: 'Control de Asistencias' },
    { key: 'calificaciones', label: 'Registro de Notas' },
    { key: 'pagos', label: 'Pagos y Tesorería' },
    { key: 'comunicados', label: 'Comunicados y Avisos' },
    { key: 'configuracion', label: 'Parámetros del Sistema' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-black text-slate-900 dark:text-white sm:text-2xl flex items-center gap-2">
            <ShieldCheck className="h-6 w-6 text-purple-600" /> Seguridad, Roles y Cifrado E2EE
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Control de accesos granulares por rol, criptografía AES-GCM 256 y bitácora de auditoría inmutable.
          </p>
        </div>

        {/* Tab navigation pills */}
        <div className="flex rounded-xl bg-slate-100 p-1 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
          <button
            onClick={() => setActiveTab('usuarios')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'usuarios'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-900 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400'
            }`}
          >
            Usuarios ({users.length})
          </button>
          <button
            onClick={() => setActiveTab('roles')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'roles'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-900 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400'
            }`}
          >
            Roles ({roles.length})
          </button>
          <button
            onClick={() => setActiveTab('cifrado')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'cifrado'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-900 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400'
            }`}
          >
            Cifrado E2EE
          </button>
          <button
            onClick={() => setActiveTab('auditoria')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'auditoria'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-900 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400'
            }`}
          >
            Auditoría
          </button>
        </div>
      </div>

      {/* TAB 1: USUARIOS */}
      {activeTab === 'usuarios' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="relative max-w-sm w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Buscar usuario o email..."
                value={searchUser}
                onChange={e => setSearchUser(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-white py-2 pl-9 pr-3 text-xs text-slate-900 focus:border-purple-500 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-white"
              />
            </div>
            <button
              onClick={handleOpenNewUser}
              className="flex items-center gap-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition-colors shadow-xs"
            >
              <Plus className="h-4 w-4" /> Nuevo Usuario
            </button>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 dark:bg-slate-800/60 dark:border-slate-800 text-slate-600 dark:text-slate-300 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="py-3 px-4">Usuario</th>
                    <th className="py-3 px-4">Rol Asignado</th>
                    <th className="py-3 px-4">Teléfono</th>
                    <th className="py-3 px-4 text-center">Estado</th>
                    <th className="py-3 px-4 text-right">Último Acceso</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {users.map(u => (
                    <tr key={u.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900 dark:text-white">{u.name}</div>
                        <div className="text-[11px] text-slate-400">{u.email}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-bold text-slate-900 bg-purple-100 dark:text-purple-200 dark:bg-purple-950 px-2.5 py-1 rounded-md uppercase text-[10px] border border-purple-200 dark:border-purple-800">
                          {u.role}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-500">{u.phone || '-'}</td>
                      <td className="py-3 px-4 text-center">
                        <span className="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                          {u.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right text-slate-400 text-[11px]">
                        {u.lastLogin ? new Date(u.lastLogin).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }) : 'Nunca'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ROLES PERSONALIZADOS & MATRIZ DE PERMISOS */}
      {activeTab === 'roles' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Roles Selector */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Perfiles de Rol
            </h3>
            <div className="space-y-2">
              {roles.map(r => (
                <button
                  key={r.id}
                  onClick={() => setSelectedRole(r)}
                  className={`w-full text-left p-3.5 rounded-2xl border transition-all ${
                    selectedRole.id === r.id
                      ? 'border-purple-600 bg-purple-100/90 text-purple-950 dark:bg-purple-950 dark:text-purple-100 shadow-sm'
                      : 'border-slate-200 bg-white text-slate-900 hover:border-slate-300 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-900 dark:text-white">{r.name}</span>
                    {r.isSystem && (
                      <span className="text-[10px] font-bold bg-slate-800 text-white px-2 py-0.5 rounded-md dark:bg-slate-700 dark:text-slate-200 shadow-xs">
                        Sistema
                      </span>
                    )}
                  </div>
                  <p className="mt-1.5 text-[11px] text-slate-700 dark:text-slate-300 line-clamp-1 font-medium leading-relaxed">{r.description}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Granular Permission Matrix */}
          <div className="md:col-span-2 rounded-2xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3 dark:border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Matriz de Permisos: {selectedRole.name}
                </h3>
                <p className="text-xs text-slate-400">{selectedRole.description}</p>
              </div>

              {!selectedRole.isSystem && (
                <button
                  onClick={handleSaveRole}
                  className="bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs px-3.5 py-1.5 rounded-xl shadow-xs transition-colors"
                >
                  Guardar Permisos
                </button>
              )}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-[10px] uppercase font-bold text-slate-400">
                    <th className="py-2.5">Módulo</th>
                    <th className="py-2.5 text-center">Lectura (Ver)</th>
                    <th className="py-2.5 text-center">Crear</th>
                    <th className="py-2.5 text-center">Modificar</th>
                    <th className="py-2.5 text-center">Eliminar</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {modulesList.map(mod => {
                    const p = selectedRole.permissions[mod.key] || { read: false, create: false, update: false, delete: false };

                    return (
                      <tr key={mod.key} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                        <td className="py-2.5 font-bold text-slate-900 dark:text-slate-100">{mod.label}</td>
                        <td className="py-2.5 text-center">
                          <input
                            type="checkbox"
                            disabled={selectedRole.isSystem}
                            checked={p.read}
                            onChange={() => handleTogglePermission(mod.key, 'read')}
                            className="rounded text-purple-600 focus:ring-purple-500 cursor-pointer disabled:opacity-60"
                          />
                        </td>
                        <td className="py-2.5 text-center">
                          <input
                            type="checkbox"
                            disabled={selectedRole.isSystem}
                            checked={p.create}
                            onChange={() => handleTogglePermission(mod.key, 'create')}
                            className="rounded text-purple-600 focus:ring-purple-500 cursor-pointer disabled:opacity-60"
                          />
                        </td>
                        <td className="py-2.5 text-center">
                          <input
                            type="checkbox"
                            disabled={selectedRole.isSystem}
                            checked={p.update}
                            onChange={() => handleTogglePermission(mod.key, 'update')}
                            className="rounded text-purple-600 focus:ring-purple-500 cursor-pointer disabled:opacity-60"
                          />
                        </td>
                        <td className="py-2.5 text-center">
                          <input
                            type="checkbox"
                            disabled={selectedRole.isSystem}
                            checked={p.delete}
                            onChange={() => handleTogglePermission(mod.key, 'delete')}
                            className="rounded text-purple-600 focus:ring-purple-500 cursor-pointer disabled:opacity-60"
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CIFRADO E2EE Y SEGURIDAD CRIPTOGRÁFICA */}
      {activeTab === 'cifrado' && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50/50 p-5 dark:border-emerald-900/40 dark:bg-emerald-950/20">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-emerald-600 text-white rounded-xl shadow-xs">
                <Lock className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-emerald-900 dark:text-emerald-200">
                  Cifrado Extremo a Extremo Activo (Web Crypto API - AES-GCM 256 bits)
                </h3>
                <p className="mt-1 text-xs text-emerald-700 dark:text-emerald-300 leading-relaxed">
                  Todos los campos de alta sensibilidad —como diagnósticos médicos, alergias, contactos de auxilio y notas psicopedagógicas del alumno— se encriptan localmente antes de almacenarse en la base de datos.
                </p>
                <div className="mt-3 flex items-center gap-3 text-xs">
                  <span className="font-mono bg-white dark:bg-slate-900 px-2 py-1 rounded border border-emerald-300 dark:border-emerald-800 text-[11px] font-bold text-emerald-800 dark:text-emerald-200">
                    Huella de Llave: {fingerprint || 'Calculando...'}
                  </span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                    PBKDF2 SHA-256 (100,000 iteraciones)
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Master Key Configuration */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Key className="h-4 w-4 text-purple-600" /> Clave Maestra de Seguridad Institucional
            </h3>
            <div className="flex gap-2">
              <input
                type="text"
                value={masterKey}
                onChange={e => setMasterKey(e.target.value)}
                placeholder="Ingresa clave maestra..."
                className="flex-1 rounded-xl border border-slate-300 p-2 text-xs dark:border-slate-700 dark:bg-slate-800 dark:text-white font-mono"
              />
              <button
                onClick={handleSaveMasterKey}
                className="bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition-colors"
              >
                Actualizar Clave
              </button>
            </div>
          </div>

          {/* Real-time Crypto Inspector / Sandbox */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <FileKey className="h-4 w-4 text-blue-600" /> Probador de Cifrado en Tiempo Real
              </h3>
              <button
                onClick={handleTestEncrypt}
                className="text-xs bg-blue-50 text-blue-700 hover:bg-blue-100 dark:bg-blue-950/60 dark:text-blue-300 font-bold px-3 py-1.5 rounded-lg transition-colors"
              >
                Ejecutar Cifrado y Descifrado
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                <span className="font-bold text-slate-400 block mb-1">1. Texto en Claro (Memoria)</span>
                <textarea
                  rows={3}
                  value={testPlaintext}
                  onChange={e => setTestPlaintext(e.target.value)}
                  className="w-full bg-transparent border-0 p-0 text-slate-800 dark:text-slate-200 focus:outline-none resize-none"
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                <span className="font-bold text-red-500 block mb-1">2. Criptograma AES-GCM (Almacenado)</span>
                <div className="font-mono text-[10px] text-slate-600 dark:text-slate-400 break-all max-h-20 overflow-y-auto">
                  {testCiphertext || 'Haz clic en "Ejecutar Cifrado" para generar el vector y criptograma.'}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                <span className="font-bold text-emerald-500 block mb-1">3. Verificación de Integridad</span>
                <p className="text-slate-800 dark:text-slate-200">{testDecrypted || 'Pendiente de prueba'}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: AUDITORÍA */}
      {activeTab === 'auditoria' && (
        <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Registro Inmutable de Eventos y Auditoría
            </h3>
            <span className="text-xs text-slate-400 font-medium">{auditLogs.length} eventos registrados</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 dark:bg-slate-800/60 dark:border-slate-800 text-slate-600 dark:text-slate-300 font-bold uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">Fecha / Hora</th>
                  <th className="py-3 px-4">Usuario</th>
                  <th className="py-3 px-4">Acción</th>
                  <th className="py-3 px-4">Módulo</th>
                  <th className="py-3 px-4">Detalles</th>
                  <th className="py-3 px-4 text-right">IP Origen</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono text-[11px]">
                {auditLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="py-2.5 px-4 text-slate-500">
                      {new Date(log.timestamp).toLocaleString([], { dateStyle: 'short', timeStyle: 'medium' })}
                    </td>
                    <td className="py-2.5 px-4 font-sans font-bold text-slate-800 dark:text-slate-200">
                      {log.userName} ({log.userRole})
                    </td>
                    <td className="py-2.5 px-4 text-blue-600 font-bold">{log.action}</td>
                    <td className="py-2.5 px-4 font-sans text-slate-600 dark:text-slate-400">{log.module}</td>
                    <td className="py-2.5 px-4 font-sans text-slate-700 dark:text-slate-300">{log.details}</td>
                    <td className="py-2.5 px-4 text-right text-slate-400">{log.ipAddress}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
