/**
 * Top Navbar with Role Switcher, Push Notifications Bell & Quick Actions
 */

import React, { useState } from 'react';
import { 
  Bell, 
  ShieldCheck, 
  UserCheck, 
  Menu, 
  Lock, 
  Unlock, 
  Sparkles,
  Search,
  ExternalLink,
  Laptop,
  Download
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import { NotificationService } from '../../services/notifications';

interface NavbarProps {
  onToggleSidebar: () => void;
  onOpenNotifications: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleSidebar, onOpenNotifications }) => {
  const { 
    config, 
    currentRole, 
    currentUser, 
    switchRole, 
    notifications, 
    runPeriodicAutomatedReport,
    encryptionUnlocked,
    setEncryptionUnlocked,
    addToast
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const unreadCount = notifications.filter(n => !n.read).length;

  const roleLabels: Record<UserRole, { label: string; bg: string; text: string }> = {
    superadmin: { label: 'Superadmin IT', bg: 'bg-purple-100 dark:bg-purple-950', text: 'text-purple-950 dark:text-purple-200' },
    director: { label: 'Directivo / Rector', bg: 'bg-blue-100 dark:bg-blue-950', text: 'text-blue-950 dark:text-blue-200' },
    docente: { label: 'Profesor / Docente', bg: 'bg-emerald-100 dark:bg-emerald-950', text: 'text-emerald-950 dark:text-emerald-200' },
    cajero: { label: 'Tesorería / Caja', bg: 'bg-amber-100 dark:bg-amber-950', text: 'text-amber-950 dark:text-amber-200' },
    padre: { label: 'Padre / Apoderado', bg: 'bg-cyan-100 dark:bg-cyan-950', text: 'text-cyan-950 dark:text-cyan-200' },
    estudiante: { label: 'Estudiante', bg: 'bg-indigo-100 dark:bg-indigo-950', text: 'text-indigo-950 dark:text-indigo-200' },
  };

  const handleRequestPushPermission = async () => {
    const res = await NotificationService.requestPermission();
    if (res === 'granted') {
      addToast('success', 'Notificaciones Activadas', 'Recibirás alertas críticas e informes en tu dispositivo.');
    } else {
      addToast('warning', 'Permiso denegado', 'Habilita las notificaciones en los ajustes de tu navegador para alertas en tiempo real.');
    }
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/95 lg:px-6">
      {/* Left: Mobile hamburger + Institution Brand */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 focus:outline-none dark:text-slate-300 dark:hover:bg-slate-800 lg:hidden"
          aria-label="Abrir Menú"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-2.5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-blue-700 to-indigo-600 text-white shadow-sm shadow-blue-500/20">
            <span className="font-extrabold text-lg tracking-wider">EC</span>
          </div>
          <div className="hidden sm:block">
            <h1 className="font-bold text-slate-900 text-sm leading-tight dark:text-white line-clamp-1">
              {config.institutionName}
            </h1>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <span className="inline-flex items-center gap-1 font-medium text-blue-600 dark:text-blue-400">
                <Laptop className="h-3 w-3" /> Ciclo {config.currentAcademicYear}
              </span>
              <span>•</span>
              <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1 font-medium">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                DB Local Ilimitada
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Middle: Quick search bar */}
      <div className="hidden md:flex items-center flex-1 max-w-xs mx-6">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar alumno, curso, recibo..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full rounded-lg border border-slate-200 bg-slate-50 py-1.5 pl-9 pr-3 text-xs text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:placeholder-slate-500"
          />
        </div>
      </div>

      {/* Right: Actions, Role Selector, E2EE status, Notifications */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Simulate Periodic Automated Report */}
        <button
          onClick={runPeriodicAutomatedReport}
          title="Ejecutar simulación de Informe Automatizado y Alerta Push"
          className="hidden xl:flex items-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50/70 px-2.5 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-100 transition-all dark:border-blue-900 dark:bg-blue-950/40 dark:text-blue-300"
        >
          <Sparkles className="h-3.5 w-3.5 text-blue-600 animate-spin" style={{ animationDuration: '4s' }} />
          <span>Simular Informe Auto</span>
        </button>

        {/* Direct ZIP download button */}
        <a
          href="/EduControl_Proyecto_Vercel.zip"
          download="EduControl_Proyecto_Vercel.zip"
          title="Descargar archivo ZIP con todo el proyecto listo para Vercel"
          className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 px-3 py-1.5 text-xs font-black text-white shadow-md shadow-emerald-500/20 transition-all cursor-pointer"
        >
          <Download className="h-3.5 w-3.5" />
          <span className="hidden lg:inline">Descargar ZIP Vercel</span>
          <span className="lg:hidden">ZIP</span>
        </a>

        {/* E2EE Lock Indicator */}
        <button
          onClick={() => {
            setEncryptionUnlocked(!encryptionUnlocked);
            addToast('info', 'Cifrado E2EE', encryptionUnlocked ? 'Expedientes sensibles bloqueados con llave maestra.' : 'Expedientes sensibles desbloqueados.');
          }}
          title={encryptionUnlocked ? 'Cifrado E2EE Activo y Desbloqueado' : 'Cifrado E2EE Protegido'}
          className={`flex items-center gap-1 rounded-lg border px-2 py-1.5 text-xs font-medium transition-colors ${
            encryptionUnlocked 
              ? 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-300' 
              : 'border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-300'
          }`}
        >
          {encryptionUnlocked ? <Unlock className="h-3.5 w-3.5 text-emerald-600" /> : <Lock className="h-3.5 w-3.5 text-amber-600" />}
          <span className="hidden sm:inline">E2EE 256-bit</span>
        </button>

        {/* Role Switcher (Crucial for testing all modules from any user perspective!) */}
        <div className="flex items-center gap-1.5 bg-slate-900 text-white dark:bg-slate-800 dark:text-white rounded-xl px-2.5 py-1.5 shadow-xs border border-slate-700/60">
          <UserCheck className="h-4 w-4 text-blue-400 shrink-0" />
          <select
            value={currentRole}
            onChange={e => switchRole(e.target.value as UserRole)}
            className="bg-transparent text-xs font-bold text-white focus:outline-none cursor-pointer pr-1"
            title="Cambiar perfil para probar cómo ve el sistema cada rol"
          >
            <option value="director" className="bg-slate-900 text-white font-bold py-2">Rol: Director</option>
            <option value="superadmin" className="bg-slate-900 text-white font-bold py-2">Rol: Superadmin</option>
            <option value="docente" className="bg-slate-900 text-white font-bold py-2">Rol: Docente</option>
            <option value="cajero" className="bg-slate-900 text-white font-bold py-2">Rol: Tesorería/Caja</option>
            <option value="estudiante" className="bg-slate-900 text-white font-bold py-2">Rol: Estudiante</option>
            <option value="padre" className="bg-slate-900 text-white font-bold py-2">Rol: Padre/Apoderado</option>
          </select>
        </div>

        {/* Push Notifications Bell */}
        <button
          onClick={onOpenNotifications}
          className="relative rounded-lg p-2 text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
          aria-label="Ver Notificaciones"
          title="Centro de Notificaciones Push"
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute top-1.5 right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-600 text-[10px] font-bold text-white shadow-sm ring-2 ring-white dark:ring-slate-900">
              {unreadCount}
            </span>
          )}
        </button>

        {/* User Mini Profile */}
        <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800">
          <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-slate-700 to-slate-900 text-white flex items-center justify-center text-xs font-bold uppercase shadow-sm">
            {currentUser.name.slice(0, 2)}
          </div>
          <div className="hidden lg:block text-left">
            <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 leading-tight">
              {currentUser.name}
            </p>
            <span className={`inline-block text-[10px] font-medium px-1.5 py-0.2 rounded-full ${roleLabels[currentRole].bg} ${roleLabels[currentRole].text}`}>
              {roleLabels[currentRole].label}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
