/**
 * Project ZIP Exporter for 1-Click Vercel Deployment
 * Packages all source files and configuration into a downloadable .zip
 */

import JSZip from 'jszip';

export class ZipExporterService {
  public static async downloadProjectZip(): Promise<void> {
    const zip = new JSZip();

    // Vite glob import of project files as raw text
    const sourceFiles = import.meta.glob(
      [
        '/src/**/*',
        '/index.html',
        '/package.json',
        '/vite.config.ts',
        '/tsconfig.json',
        '/vercel.json',
        '/.gitignore',
      ],
      { query: '?raw', import: 'default', eager: true }
    );

    // Add each file to the zip archive
    for (const [path, content] of Object.entries(sourceFiles)) {
      // Remove leading slash if present
      const cleanPath = path.startsWith('/') ? path.slice(1) : path;
      if (typeof content === 'string') {
        zip.file(cleanPath, content);
      }
    }

    // Include a helpful README for Vercel
    const readmeContent = `# EduControl - Sistema Integral de Gestión Educativa

Este proyecto está 100% listo para ser desplegado en Vercel.

## Cómo desplegar en Vercel en 30 segundos:

### Opción 1: Arrastrar y soltar en Vercel
1. Descomprime este archivo .zip en una carpeta de tu computadora.
2. Abre la terminal en esa carpeta y ejecuta:
   \`\`\`bash
   npm install -g vercel
   vercel
   \`\`\`
3. ¡Listo! Vercel te entregará tu enlace público HTTPS gratuito.

### Opción 2: Subir a GitHub y conectar con Vercel
1. Crea un repositorio en https://github.com/new
2. Sube esta carpeta a tu repositorio.
3. Entra en https://vercel.com/new e importa el repositorio.
4. Vercel detectará la configuración de Vite y vercel.json automáticamente.
5. Haz clic en "Deploy" y estará en línea de inmediato.
`;

    zip.file('README.md', readmeContent);

    // Generate blob and trigger browser download
    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', url);
    downloadAnchor.setAttribute('download', `EduControl_Proyecto_Vercel_${new Date().toISOString().slice(0, 10)}.zip`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    URL.revokeObjectURL(url);
  }
}
